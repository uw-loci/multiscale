
========================

This project contains custom functions to manipulate images, for use at LOCI,
and in combination with CurveAlign.

